from reportlab.pdfgen import canvas

def generate_certificate(volunteer_name, hours):
    file_name = f"{volunteer_name}_certificate.pdf"
    c = canvas.Canvas(file_name)
    c.drawString(100, 750, "Volunteer Certificate")
    c.drawString(100, 700, f"Name: {volunteer_name}")
    c.drawString(100, 670, f"Total Hours: {hours}")
    c.save()
    return file_name
