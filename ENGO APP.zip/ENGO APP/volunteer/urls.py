from django.urls import path
from . import views

app_name = 'volunteers'

urlpatterns = [
    
    path('dashboard/', views.volunteer_dashboard, name='dashboard'),
    path('profile_settings/',views.profile_settings,name='profile_settings'),
    path('campaigns/', views.campaigns_view, name='campaigns'),
   path('apply/<int:campaign_id>/', views.apply_campaign, name='apply_campaign'),
    path('hours-feedback/', views.hours_feedback, name='hours_feedback'),
    path('api/map-data/', views.map_data_api, name='map_data_api'),
    path('generate-resume/', views.generate_social_resume, name='generate_social_resume'),
   path('volunteer_profile_view/',views.volunteer_profile_view,name='volunteer_profile_view'),
    
    path('donations/', views.donation_list, name='donation_list'),
    path('api/analytics/', views.analytics_data, name='analytics_data'),
    path('public_ledger/',views.public_ledger,name='public_ledger'),
]