from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import models
from csr.models import CSRCampaign  

# =====================================================
# 📂 CHOICES & CONSTANTS
# =====================================================
NGO_CATEGORIES = [
    ('education', 'Education'),
    ('health', 'Health'),
    ('environment', 'Environment'),
    ('social', 'Social/Corporate'),
]

# =====================================================
# 🧑‍🤝‍🧑 VOLUNTEER & PROFILE
# =====================================================
class Volunteer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,related_name="+")
    total_hours = models.IntegerField(default=0)
    leaderboard_rank = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return self.user.username

class VolunteerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    skills = models.CharField(max_length=500, help_text="Comma separated skills")
    education = models.CharField(max_length=255)
    total_hours = models.PositiveIntegerField(default=0)
    verified_projects = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.user.username}'s Profile"

# =====================================================
# 🏢 NGO & CSR
# =====================================================
class NGO(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255, default="NGO")
    category = models.CharField(max_length=50, choices=NGO_CATEGORIES, default='social')
    trust_score = models.IntegerField(default=90)
    description = models.TextField(blank=True)
    location = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.name

class CSR(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=255)
    industry = models.CharField(max_length=100, blank=True)
    
    def __str__(self):
        return self.company_name

# =====================================================
# 🌍 CAMPAIGN & REQUIREMENTS
# =====================================================
class Campaign(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, null=True, blank=True)
    csr = models.ForeignKey(CSR, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=255)
    mission = models.TextField()
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    is_emergency = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# 📢 NGO Requirement (ફક્ત એક જ વાર ડિક્લેર કરો)
class NGORequirement(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name="requirements")
    title = models.CharField(max_length=200)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=NGO_CATEGORIES)
    amount_needed = models.DecimalField(max_digits=10, decimal_places=2)
    amount_received = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    is_active = models.BooleanField(default=True)
    is_urgent = models.BooleanField(default=False)  # Urgent Feature
    status = models.CharField(max_length=20, default='Pending') 
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ngo.name} - {self.title}"

    @property
    def progress_percentage(self):
        if self.amount_needed > 0:
            percent = (float(self.amount_received) / float(self.amount_needed)) * 100
            return min(percent, 100)
        return 0

# 💰 Donation History
class Donation(models.Model):
    donor = models.ForeignKey(User, on_delete=models.CASCADE, related_name="volunteer_donations")
    # 'NGORequirement' ને સીધું વાપરો કારણ કે તે હવે ઉપર ડિક્લેર થઈ ગયું છે
    requirement = models.ForeignKey(NGORequirement, on_delete=models.CASCADE, related_name="donations")
    amount = models.FloatField()
    transaction_id = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

# =====================================================
# 🏆 COMMUNICATION & SYSTEM
# =====================================================
class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE,related_name="+")
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class ChatMessage(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sent_messages")
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name="received_messages")
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)


class CampaignApplication(models.Model):
    volunteer = models.ForeignKey(Volunteer, on_delete=models.CASCADE)
    campaign = models.ForeignKey(CSRCampaign, on_delete=models.CASCADE)
    applied_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = ('volunteer', 'campaign')

class VolunteerHour(models.Model):
    volunteer = models.ForeignKey(Volunteer, on_delete=models.CASCADE)
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE, null=True, blank=True)
    hours = models.IntegerField()
    date = models.DateField(db_index=True)

# =====================================================
# 🔔 SIGNALS (NGO Notification Logic)
# =====================================================
@receiver(post_save, sender=Donation)
def notify_ngo_on_donation(sender, instance, created, **kwargs):
    if created:
        # NGO ના યુઝરને નોટિફિકેશન મોકલો
        Notification.objects.create(
            user=instance.requirement.ngo.user,
            message=f"નવું ડોનેશન: {instance.donor.username} દ્વારા ₹{instance.amount} '{instance.requirement.title}' માટે મળ્યું છે! 🎉"
        )

# =====================================================
# 📝 FEEDBACK & EXPERIENCE (Missing Models Fix)
# =====================================================
class Feedback(models.Model):
    volunteer = models.ForeignKey(Volunteer, on_delete=models.CASCADE)
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE, null=True, blank=True)
    text = models.TextField()
    sentiment = models.CharField(max_length=20, default='neutral') 
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.volunteer.user.username}"

class SocialWorkExperience(models.Model):
    volunteer = models.ForeignKey(VolunteerProfile, on_delete=models.CASCADE, related_name='experiences')
    ngo_name = models.CharField(max_length=255)
    role = models.CharField(max_length=100)
    description = models.TextField()
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.role} at {self.ngo_name}"