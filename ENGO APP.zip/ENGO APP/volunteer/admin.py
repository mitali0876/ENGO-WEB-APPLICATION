from django.contrib import admin
from .models import Volunteer, VolunteerProfile, CampaignApplication, VolunteerHour

# 1. Volunteer Profile Admin 
@admin.register(VolunteerProfile)
class VolunteerProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'skills', 'total_hours', 'verified_projects')
    search_fields = ('user__username', 'skills', 'education')
    list_filter = ('education',)

# 2. Volunteer Admin
@admin.register(Volunteer)
class VolunteerAdmin(admin.ModelAdmin):
    list_display = ('user', 'total_hours', 'leaderboard_rank')
    search_fields = ('user__username',)
    list_editable = ('leaderboard_rank',) 

# 3.
admin.site.register(CampaignApplication)
admin.site.register(VolunteerHour)