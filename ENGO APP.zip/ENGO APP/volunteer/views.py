import csv
from datetime import date
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum, Count
from django.db.models.functions import TruncMonth
from textblob import TextBlob
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from csr.models import CSRCampaign
from csr.models import CSRTransaction
from volunteer.models import VolunteerHour
import uuid
from django.contrib import messages
from .models import (
    Volunteer, VolunteerProfile, NGO, NGORequirement, 
     CampaignApplication, VolunteerHour, 
    Feedback, Donation, Notification,SocialWorkExperience
)

# --- હેલ્પર ફંક્શન ---
def get_volunteer(user):
    v, _ = Volunteer.objects.get_or_create(user=user)
    return v
@login_required
def profile_settings(request):
    # Get or Create the profile object for the user
    profile, created = VolunteerProfile.objects.get_or_create(user=request.user)
    
    if request.method == "POST":
        # Get data from the form
        profile.bio = request.POST.get('bio')
        profile.skills = request.POST.get('skills')
        profile.education = request.POST.get('education')
        profile.save()
        
        # Optional: Save Social Experience if data exists
        ngo_name = request.POST.get('ngo_name')
        if ngo_name:
            SocialWorkExperience.objects.create(
                volunteer=profile,
                ngo_name=ngo_name,
                role=request.POST.get('role'),
                start_date="2024-01-01" # Placeholder
            )
            
        return redirect('volunteers:dashboard')

    return render(request, "volunteers/profile_settings.html", {"profile": profile})

def get_skill_recommendations(volunteer, all_campaigns):
    try:
        profile = VolunteerProfile.objects.get(user=volunteer.user)
        # Convert comma-separated string to list
        v_skills = [s.strip().lower() for s in profile.skills.split(',') if s.strip()]
    except VolunteerProfile.DoesNotExist:
        return all_campaigns

    recommended, others = [], []
    
    for c in all_campaigns:
        # FIX: Changed 'c.mission' to 'c.description' to match CSRCampaign model
        content = (c.title + " " + (c.description or "")).lower()
        
        if any(skill in content for skill in v_skills):
            c.is_match = True
            recommended.append(c)
        else:
            c.is_match = False
            others.append(c)
            
    return recommended + others


from django.db.models import Sum

@login_required
def volunteer_dashboard(request):
    volunteer = get_volunteer(request.user)
    total_hours_sum = VolunteerHour.objects.filter(volunteer=volunteer).aggregate(Sum('hours'))['hours__sum'] or 0
    if volunteer.total_hours != total_hours_sum:
        volunteer.total_hours = total_hours_sum
        volunteer.save()

    badges = []
    if total_hours_sum >= 10: badges.append({"name": "Bronze", "icon": "🥉"})
    if total_hours_sum >= 50: badges.append({"name": "Silver", "icon": "🥈"})
    if total_hours_sum >= 100: badges.append({"name": "Gold", "icon": "🥇"})
    
    return render(request, "volunteers/volunteer_dashboard.html", {
        "volunteer": volunteer,
        "badges": badges,
        "total_hours": total_hours_sum  
    })

def campaigns_view(request):
    
    campaigns_qs = CSRCampaign.objects.filter(status='Active').order_by('-created_at')
    
    if request.user.is_authenticated:
        volunteer = get_volunteer(request.user)
        campaigns_list = get_skill_recommendations(volunteer, campaigns_qs)
    else:
        campaigns_list = campaigns_qs

    return render(request, 'volunteers/campaigns.html', {'campaigns': campaigns_list})


@login_required
def apply_campaign(request, campaign_id):
    try:
        # 1. Get the Campaign from CSR app
        campaign = get_object_or_404(CSRCampaign, id=campaign_id)
        
        # 2. Get the Volunteer object
        volunteer, _ = Volunteer.objects.get_or_create(user=request.user)
        
        # 3. Create Application
        application, created = CampaignApplication.objects.get_or_create(
            volunteer=volunteer, 
            campaign=campaign
        )
        
        if created:
            return JsonResponse({"status": "success", "message": f"Joined {campaign.title}!"})
        else:
            return JsonResponse({"status": "exists", "message": "Already applied!"})
            
    except Exception as e:
        # This will print the exact error in your VS Code terminal
        print(f"CRASH ERROR: {e}") 
        return JsonResponse({"status": "error", "message": str(e)}, status=500)

@login_required
def hours_feedback(request):
    if request.method == "POST":
        hours_val = request.POST.get("hours")
        feedback_text = request.POST.get("feedback")
        
        volunteer = get_volunteer(request.user)
        if hours_val:
            h = float(hours_val)
            VolunteerHour.objects.create(volunteer=volunteer, hours=h, date=date.today())
            volunteer.total_hours += h
            volunteer.save()
            return JsonResponse({"status": "success"})
        if feedback_text:
            fb = Feedback.objects.create(volunteer=volunteer, text=feedback_text)
            # Sentiment Analysis logic here...
            fb.save()
            return JsonResponse({"status": "success"})

    return render(request, "volunteers/hours_feedback.html")

@login_required
def generate_social_resume(request):
    volunteer = get_volunteer(request.user)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{request.user.username}_impact.pdf"'
    
    p = canvas.Canvas(response, pagesize=letter)
    p.setFont("Helvetica-Bold", 20)
    p.drawCentredString(300, 750, "ECONEXUS IMPACT RESUME")
    p.setFont("Helvetica", 12)
    p.drawString(100, 700, f"Name: {request.user.username}")
    p.drawString(100, 680, f"Total Hours: {volunteer.total_hours}")
    p.line(100, 670, 500, 670)
    p.drawString(100, 650, "Verified by EcoNexus AI System 2026")
    p.showPage()
    p.save()
    return response


def map_data_api(request):
    campaigns = CSRCampaign.objects.all().values('id', 'title', 'latitude', 'longitude')
    return JsonResponse(list(campaigns), safe=False)

@login_required
def donation_list(request):
    if request.method == "POST":
        req_id = request.POST.get('requirement_id')
        amount = float(request.POST.get('amount', 0))
        requirement = get_object_or_404(NGORequirement, id=req_id)
        
        # Create Donation Record
        Donation.objects.create(
            donor=request.user,
            requirement=requirement,
            amount=amount,
            transaction_id=str(uuid.uuid4()).replace('-', '').upper()[:12]
        )
        
        # Update NGO Requirement progress
        requirement.amount_received = float(requirement.amount_received) + amount
        requirement.save()
        
        messages.success(request, f"Thank you! You donated ₹{amount} to {requirement.title}")
        return redirect('volunteers:donation_list')

    # GET logic
    requirements = NGORequirement.objects.filter(is_active=True).order_by('-is_urgent', '-created_at')
    user_donations = Donation.objects.filter(donor=request.user).order_by('-created_at')
    
    return render(request, "volunteers/donations.html", {
        "requirements": requirements,
        "user_donations": user_donations
    })

@login_required
def volunteer_profile_view(request):
    volunteer = get_volunteer(request.user)
    profile = VolunteerProfile.objects.get(user=request.user)
    
    return render(request, "volunteers/volunteer_details.html", {
        "volunteer": volunteer,
        "profile": profile
    })

def analytics_data(request):
    data = VolunteerHour.objects.annotate(month=TruncMonth("date")).values("month").annotate(total=Sum("hours")).order_by("month")
    result = [{"month": d["month"].strftime("%Y-%m-%d"), "total": d["total"]} for d in data if d["month"]]
    return JsonResponse(result, safe=False)

@login_required
def public_ledger(request):
    # Fetch latest financial transactions
    transactions = CSRTransaction.objects.all().order_by('-created_at')
    
    # Fetch latest volunteer impact logs
    volunteer_hours = VolunteerHour.objects.all().order_by('-date')
    
    return render(request, "volunteers/ledger.html", {
        "transactions": transactions,
        "volunteer_hours": volunteer_hours
    })