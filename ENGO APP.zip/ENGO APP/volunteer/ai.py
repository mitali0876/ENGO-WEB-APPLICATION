from .models import VolunteerProfile, VolunteerFeedback
from textblob import TextBlob

def match_volunteers(required_skills):
    skills = required_skills.lower().split(',')
    matched = []

    for v in VolunteerProfile.objects.all():
        if any(skill.strip() in v.skills.lower() for skill in skills):
            matched.append(v)

    return matched
def suggest_schedule(volunteer):
    return f"Suggested slot based on availability: {volunteer.availability}"
#🔹 Sentiment Analysis
def analyze_sentiment(feedback_text):
    polarity = TextBlob(feedback_text).sentiment.polarity
    return "Positive" if polarity > 0 else "Negative"