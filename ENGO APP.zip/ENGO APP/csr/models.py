import uuid
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver
from decimal import Decimal

# 1. Corporate Profile: Stores company-specific details linked to a User
class CorporateCSRProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    company_name = models.CharField(max_length=255)
    csr_budget = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    industry = models.CharField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.company_name

# 2. CSR Campaign: Represents specific social initiatives created by a Corporate
class CSRCampaign(models.Model):
    STATUS_CHOICES = (
        ('Active', 'Active'),
        ('Completed', 'Completed'),
        ('Paused', 'Paused'),
    )
    corporate = models.ForeignKey(CorporateCSRProfile, on_delete=models.CASCADE, related_name="campaigns")
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='campaigns/', null=True, blank=True)
    target_amount = models.DecimalField(max_digits=12, decimal_places=2)
    funded_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Active')
    blockchain_hash = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    # Calculates the funding progress as a percentage
    def progress_percentage(self):
        if self.target_amount > 0:
            return int((self.funded_amount / self.target_amount) * 100)
        return 0

    def __str__(self):
        return self.title

# 3. CSR Transaction: Records financial movement and generates a unique Blockchain Hash
class CSRTransaction(models.Model):
    campaign = models.ForeignKey(CSRCampaign, on_delete=models.CASCADE, related_name="transactions")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True) # Used for ledger timestamp
    blockchain_hash = models.CharField(max_length=64, unique=True, editable=False, blank=True)

    def save(self, *args, **kwargs):
        # 1. Decimal Conversion 
        if isinstance(self.amount, str):
            self.amount = Decimal(self.amount)

        if not self.blockchain_hash:
            self.blockchain_hash = uuid.uuid4().hex + uuid.uuid4().hex # hash

        # 3. Update Campaign Amount 
        if not self.pk:
            self.campaign.funded_amount += self.amount
            self.campaign.save()

        super().save(*args, **kwargs)

# 4. Employee Volunteer: Tracks individual employee contributions and skills
class EmployeeVolunteer(models.Model):
    corporate = models.ForeignKey(CorporateCSRProfile, on_delete=models.CASCADE)
    employee_name = models.CharField(max_length=100)
    skill = models.CharField(max_length=100, default="General")
    hours_contributed = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)
    participated_on = models.DateTimeField(default=timezone.now)

# 5. Signals: Automatically create a Corporate Profile when a new User is registered
@receiver(post_save, sender=User)
def handle_user_profile(sender, instance, created, **kwargs):
    if created:
        CorporateCSRProfile.objects.get_or_create(
            user=instance, 
            defaults={'company_name': instance.username}
        )

class CSRCompliance(models.Model):
    corporate = models.ForeignKey(CorporateCSRProfile, on_delete=models.CASCADE)
    fiscal_year = models.CharField(max_length=20) # e.g., 2025-26
    required_spend = models.DecimalField(max_digits=15, decimal_places=2)
    actual_spend = models.DecimalField(max_digits=15, decimal_places=2, default=0) 
    compliance_status = models.CharField(max_length=20, blank=True)
    
    # English: Automatically update status before saving
    def save(self, *args, **kwargs):
        self.compliance_status = "Compliant" if self.actual_spend >= self.required_spend else "Pending"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.corporate.company_name} - {self.fiscal_year}"
    
class CSRCertificate(models.Model):
    corporate = models.ForeignKey('CorporateCSRProfile', on_delete=models.CASCADE, related_name="certificates")
    campaign = models.ForeignKey('CSRCampaign', on_delete=models.CASCADE)
    
   
    certificate_type = models.CharField(max_length=100, default="Certificate of Social Impact")
    fiscal_year = models.CharField(max_length=20, default="2025-26")
    issued_date = models.DateTimeField(auto_now_add=True)
    blockchain_hash = models.CharField(max_length=255, unique=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.blockchain_hash:
            # unique id
            self.blockchain_hash = f"BLOCK-{uuid.uuid4().hex[:16].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.certificate_type} - {self.campaign.title}"