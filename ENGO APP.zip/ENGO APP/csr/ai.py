

#🔹 ESG Analytics
def esg_score(environment, social, governance):
    return round((environment + social + governance) / 3, 2)
#🔹 CSR Impact Scoring
def csr_impact(beneficiaries, funds):
    return round(beneficiaries / funds, 3)
#🔹 Predictive CSR Planning
def predict_csr_budget(annual_profit):
    return round(annual_profit * 0.02, 2) 