import hashlib
#🔹 CSR Fund Utilization Hash
def csr_hash(corporate, campaign, amount, timestamp):
    data = f"{corporate}{campaign}{amount}{timestamp}"
    return hashlib.sha256(data.encode()).hexdigest()
#🔹 Public Audit Trail
def log_csr_donation(donation):
    return csr_hash(
        donation.corporate.id,
        donation.campaign.id,
        donation.amount,
        donation.timestamp
    )
