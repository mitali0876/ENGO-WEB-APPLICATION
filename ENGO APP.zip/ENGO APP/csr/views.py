from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from decimal import Decimal
from django.http import JsonResponse, Http404
from .models import CSRTransaction, CSRCampaign, CorporateCSRProfile, EmployeeVolunteer, CSRCompliance, CSRCertificate
from .forms import CampaignForm
from django.db.models import Sum
from django.http import JsonResponse
import hashlib
import time
from decimal import Decimal

# ---------------- CSR DASHBOARD ----------------
@login_required
def csr_dashboard(request):
   
    total_spent = CSRTransaction.objects.all().aggregate(total=Sum('amount'))['total'] or 0
    corporate = CorporateCSRProfile.objects.filter(user=request.user).first()

    return render(request, 'csr/dashboard.html', {
        'corporate': corporate,
        'total_spent': total_spent
    })

@login_required
def corporate_dashboard(request):
    corporate, _ = CorporateCSRProfile.objects.get_or_create(user=request.user)
    context = {'corporate': corporate}
    return render(request, 'csr/corporate.html', context)

# ---------------- CSR CAMPAIGNS (ALL) ----------------
@login_required
def csr_campaigns(request):
    corporate = get_object_or_404(CorporateCSRProfile, user=request.user)
    
    if request.method == "POST":
        campaign_id = request.POST.get('campaignId')
        
        if campaign_id:
            instance = get_object_or_404(CSRCampaign, id=campaign_id)
            form = CampaignForm(request.POST, request.FILES, instance=instance)
        else:
            form = CampaignForm(request.POST, request.FILES)

        if form.is_valid():
            campaign = form.save(commit=False)
            campaign.corporate = corporate
            campaign.save()
            
            # --- SYNC LOGIC ---
            from donor.models import Campaign as DonorCampaign
            
            # Title ane User thi match karishu
            donor_camp, created = DonorCampaign.objects.get_or_create(
                title=campaign.title,
                user=request.user,
                defaults={
                    'description': campaign.description,
                    'goal_amount': campaign.target_amount,
                    'raised_amount': 0,
                    'category': 'Corporate CSR',
                    'is_active': True,
                    # Jo image model ma hovi joie, else delete this line
                    'image': campaign.image if hasattr(campaign, 'image') and campaign.image else None,
                }
            )
            
            # Jo already hovun joie to update kari dyo
            if not created:
                donor_camp.description = campaign.description
                donor_camp.goal_amount = campaign.target_amount
                donor_camp.save()
            
            print(f"DEBUG:  Campaign Created: {created}")
            return JsonResponse({"status": "success"})
        else:
            return JsonResponse({"status": "error", "errors": form.errors}, status=400)

    # GET Request: Fetch all campaigns
    campaigns = CSRCampaign.objects.all().order_by('-created_at')
    form = CampaignForm() 
    
    return render(request, 'csr/fund_campaign.html', {
        'campaigns': campaigns,
        'form': form
    })


# ---------------- DELETE CAMPAIGN ----------------
@login_required
def delete_campaign(request, id):
    if request.method == "POST":
        try:
            campaign = get_object_or_404(CSRCampaign, id=id)
            campaign.delete()
            return JsonResponse({"status": "success", "message": "Deleted successfully"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)
            
    return JsonResponse({"status": "error", "message": "Invalid request method"}, status=400)
# ---------------- EMPLOYEE VOLUNTEER (ALL) ----------------
@login_required
def employee_volunteer(request):
    corporate, created = CorporateCSRProfile.objects.get_or_create(user=request.user)
    
    # .all() નો ઉપયોગ
    volunteers = EmployeeVolunteer.objects.all().order_by('-hours_contributed')

    if request.method == "POST":
        name = request.POST.get('employee_name')
        skill = request.POST.get('skill')
        hours = request.POST.get('hours')
        
        EmployeeVolunteer.objects.create(
            corporate=corporate,
            employee_name=name,
            skill=skill,
            hours_contributed=hours
        )
        return redirect('csr:employee_volunteer')

    return render(request, 'csr/employee_volunteer.html', {
        'volunteers': volunteers
    })

# --- EDIT VOLUNTEER ---
@login_required
def edit_volunteer(request, pk):
    v = get_object_or_404(EmployeeVolunteer, pk=pk)
    if request.method == "POST":
        v.employee_name = request.POST.get('employee_name')
        v.skill = request.POST.get('skill')
        v.hours_contributed = request.POST.get('hours')
        v.save()
        return redirect('csr:employee_volunteer')
    return render(request, 'csr/edit_volunteer.html', {'v': v})

# --- DELETE VOLUNTEER ---
@login_required
def delete_volunteer(request, pk):
    volunteer = get_object_or_404(EmployeeVolunteer, pk=pk)
    volunteer.delete()
    return redirect('csr:employee_volunteer')

# ---------------- CSR CERTIFICATES (ALL) ----------------
def csr_certificates(request):
    certificates = CSRCertificate.objects.all().select_related('corporate', 'campaign')
    return render(request, 'csr/certificates.html', {
        'certificates': certificates
    })

# ---------------- CSR COMPLIANCE (ALL) ----------------
@login_required
def csr_compliance(request):
    corporate = get_object_or_404(CorporateCSRProfile, user=request.user)
    
    if request.method == "POST":
        CSRCompliance.objects.create(
            corporate=corporate,
            fiscal_year=request.POST.get('fiscal_year'),
            required_spend=request.POST.get('required_spend'),
            actual_spend=request.POST.get('actual_spend')
        )
        return redirect('csr:csr_compliance')

    # .all() નો ઉપયોગ
    compliances = CSRCompliance.objects.all().order_by('-fiscal_year')
    return render(request, 'csr/compliance.html', {'compliances': compliances})

# ---------------- CSR LEDGER (ALL) ----------------
@login_required
def csr_ledger(request):

    transactions = CSRTransaction.objects.all().order_by('-created_at')
    campaigns = CSRCampaign.objects.all()
    total_amount = transactions.aggregate(Sum('amount'))['amount__sum'] or 0
    
    return render(request, 'csr/ledger.html', {
        'transactions': transactions,
        'campaigns': campaigns,
        'total_amount': total_amount
    })

def add_transaction(request):
    if request.method == "POST":
        campaign_id = request.POST.get('campaign')
        amount = Decimal(request.POST.get('amount'))
        campaign = get_object_or_404(CSRCampaign, pk=campaign_id)
        CSRTransaction.objects.create(campaign=campaign, amount=amount)
    return redirect('csr:csr_ledger')

def edit_transaction(request, pk):
    tx = get_object_or_404(CSRTransaction, pk=pk)
    if request.method == "POST":
        old_amount = tx.amount
        new_amount = request.POST.get('amount')
        tx.campaign.funded_amount = (tx.campaign.funded_amount - old_amount) + float(new_amount)
        tx.campaign.save()
        tx.amount = new_amount
        tx.save()
        return redirect('csr:csr_ledger')

def delete_transaction(request, pk):
    tx = get_object_or_404(CSRTransaction, pk=pk)
    tx.campaign.funded_amount -= tx.amount
    tx.campaign.save()
    tx.delete()
    return redirect('csr:csr_ledger')
    
# ---------------- BLOCKCHAIN VERIFY ----------------
def csr_certificates(request):
    # .all() 
    certificates = CSRCertificate.objects.all()
    
    # DEBUG:
    print(f"--- DEBUG START ---")
    print(f"Total Certs in DB: {certificates.count()}")
    for c in certificates:
        print(f"Found: {c.certificate_type} for {c.campaign}")
    print(f"--- DEBUG END ---")

    return render(request, 'csr/certificates.html', {
        'certificates': certificates  
    })

# ---------------- BLOCKCHAIN VERIFY ----------------
def verify_blockchain(request, hash): 
    """
    Validates the authenticity of a certificate.
    In a real app, this would check against a ledger or node.
    """
    try:
        certificate = get_object_or_404(CSRCertificate, blockchain_hash=hash)
        # Mocking validation details
        validation_details = {
            "status": "Verified",
            "node_id": hashlib.sha256(str(certificate.id).encode()).hexdigest()[:12],
            "timestamp": certificate.issued_date,
            "block_height": 14200 + certificate.id
        }
        return render(request, 'csr/verify_success.html', {
            'certificate': certificate,
            'details': validation_details
        })
    except Http404:
        return render(request, 'csr/verify_success.html', {'hash': hash})