from django.urls import path
from . import views
app_name = 'csr'
urlpatterns = [
    path('', views.csr_dashboard, name='csr_dashboard'),
 
   # csr/urls.py
path('dashboard/', views.corporate_dashboard, name='corporate_dashboard'), 
    path('campaigns/', views.csr_campaigns, name='csr_campaigns'),
   
    path('campaign/delete/<int:id>/', views.delete_campaign, name='delete_campaign'),
    path('volunteers/', views.employee_volunteer, name='employee_volunteer'),
    path('volunteer/edit/<int:pk>/', views.edit_volunteer, name='edit_volunteer'),
    path('volunteer/delete/<int:pk>/', views.delete_volunteer, name='delete_volunteer'),
    path('certificates/', views.csr_certificates, name='csr_certificates'),
    
    path('compliance/', views.csr_compliance, name='csr_compliance'),
   
    path('verify/<str:hash>/', views.verify_blockchain, name='verify_blockchain'),
    path('ledger/', views.csr_ledger, name='csr_ledger'),
    path('ledger/add/', views.add_transaction, name='add_transaction'),
    path('ledger/edit/<int:pk>/', views.edit_transaction, name='edit_transaction'),
    path('ledger/delete/<int:pk>/', views.delete_transaction, name='delete_transaction'),
   
    
]



