from django import forms
from .models import CSRCampaign, CSRTransaction, EmployeeVolunteer, CSRCompliance  
class CampaignForm(forms.ModelForm):
    class Meta:
        model = CSRCampaign
        fields = ['title', 'description', 'target_amount', 'image']

class TransactionForm(forms.ModelForm):
    class Meta:
        model = CSRTransaction
        fields = ['campaign', 'amount']


class VolunteerForm(forms.ModelForm):
    class Meta:
        model = EmployeeVolunteer
        fields = ['employee_name', 'skill', 'hours_contributed']

class CSRComplianceForm(forms.ModelForm):
    class Meta:
        model = CSRCompliance  
        fields = ['fiscal_year', 'required_spend', 'actual_spend']
        
        widgets = {
            'fiscal_year': forms.TextInput(attrs={'class': 'w-full p-3 rounded-xl border border-slate-200'}),
            'required_spend': forms.NumberInput(attrs={'class': 'w-full p-3 rounded-xl border border-slate-200'}),
            'actual_spend': forms.NumberInput(attrs={'class': 'w-full p-3 rounded-xl border border-slate-200'}),
        }