from django.shortcuts import render
from donor.models import Campaign
def home(request):
    return render(request, "core/home.html")
def about(request):
    return render(request, "core/about.html")
def join_mission(request):
    return render(request, "core/join_mission.html")

def interventions(request):
    # Example: show only active campaigns
    
    return render(request, "core/interventions.html")


def get_involved(request):
    return render(request, "core/get_involved.html")


def resources(request):
    # Example: static + dynamic resources
    resources = [
        {"title": "Annual Report", "type": "PDF"},
        {"title": "Impact Stories", "type": "Blog"},
        {"title": "Transparency Report", "type": "Page"},
    ]
    return render(request, "core/resources.html", {
        "resources": resources
    })
