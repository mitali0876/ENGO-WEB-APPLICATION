from django.urls import path
from . import views

app_name = "core"

urlpatterns = [
    path("about/", views.about, name="about"),
     path("home/", views.home, name="home"),
     path("join_mission/", views.join_mission, name="join_mission"),
    path("interventions/", views.interventions, name="interventions"),
    path("get-involved/", views.get_involved, name="get_involved"),
    path("resources/", views.resources, name="resources"),
]
