from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from django.http import JsonResponse
import hashlib, time

@staff_member_required
def system_admin_dashboard(request):
    """
    System Admin Control Center
    - Only staff / superusers allowed
    - Later: inject API data
    """
    return render(request, 'system_admin.html')

def deploy_funds(request):
    if request.method == "POST":
        ngo_id = request.POST.get('ngo_id')
        amount = request.POST.get('amount')
        
        # SHA-256 Hash Generation for Audit
        raw_data = f"{ngo_id}{amount}{time.time()}"
        tx_hash = hashlib.sha256(raw_data.encode()).hexdigest()
        
        # Async Task Simulation (Celery)
        # process_blockchain_entry.delay(tx_hash) 
        
        return JsonResponse({
            "status": "success",
            "tx_hash": tx_hash,
            "message": "Fund Deployed via Nexus AI Core"
        })
