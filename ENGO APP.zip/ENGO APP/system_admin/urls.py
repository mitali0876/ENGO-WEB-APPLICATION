from django.urls import path
from .views import system_admin_dashboard
app_name = "system_admin"  # namespacing
urlpatterns = [
    path('', system_admin_dashboard, name='system_admin'),
]
