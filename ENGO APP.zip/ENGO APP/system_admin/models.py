from django.db import models
from django.contrib.auth.models import User

# --- ૧. NGO (TENANT) MANAGEMENT ---
# SQLite માં Schema નથી હોતા, એટલે આપણે સાદું Model વાપરીશું.
class NGO(models.Model):
    name = models.CharField(max_length=255)
    # unique ID જે સબડોમેન તરીકે કામ કરી શકે (દા.ત. 'seva-foundation')
    tenant_id = models.SlugField(max_length=63, unique=True) 
    region = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

# --- ૨. ROLE & PERMISSIONS ---
class Role(models.Model):
    name = models.CharField(max_length=50) # e.g., Admin, Manager, Volunteer
    permissions = models.JSONField(default=dict) # JSON format માં પરમિશન સ્ટોર થશે

    def __str__(self):
        return self.name

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, null=True, blank=True)
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.user.username} - {self.ngo.name if self.ngo else 'SuperAdmin'}"

# --- ૩. AUDIT LOGS (SECURITY) ---
class AuditLog(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, null=True, blank=True)
    action = models.CharField(max_length=255)
    performed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    details = models.TextField(default="System generated log entry")

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.action} - {self.timestamp}"

# --- ૪. TRANSACTION & FUND TRACKING ---
class Transaction(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    tx_hash = models.CharField(max_length=64, unique=True) # Blockchain-style Unique Hash
    status = models.CharField(max_length=20, default='Verified')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"₹{self.amount} to {self.ngo.name}"

# --- ૫. SYSTEM MONITORING (INFRASTRUCTURE) ---
class SystemMetric(models.Model):
    METRIC_TYPES = (
        ('CPU', 'CPU Usage'),
        ('RAM', 'Memory Usage'),
        ('DSK', 'Disk Space'),
        ('LAT', 'API Latency'),
    )
    metric_type = models.CharField(max_length=3, choices=METRIC_TYPES)
    value = models.FloatField() # e.g., 45.5
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.metric_type}: {self.value}"

# --- ૬. AI ANOMALY DETECTION (FUTURE SCOPE) ---
class AnomalyEvent(models.Model):
    LEVELS = (
        ('LOW', 'Low Risk'),
        ('MED', 'Medium Risk'),
        ('HIG', 'High Risk / Critical'),
    )
    level = models.CharField(max_length=3, choices=LEVELS)
    description = models.TextField()
    is_resolved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.level} Anomaly at {self.created_at}"