from django.urls import path
from . import views

app_name = 'ngo_admin'




urlpatterns = [
    # 1. Main Dashboard
    path('', views.dashboard_view, name='dashboard'),

    # 2. NGO Management (Features: Create & Directory)
    path('ngo/create/', views.create_ngo_page, name='create_ngo_page'),
    path('ngo/list/', views.ngo_list, name='ngo_list'),

    # 3. Volunteers (Feature: Approval)
    path('volunteers/', views.volunteer_list, name='volunteer_list'),
    path('approve-volunteer/<int:profile_id>/', views.approve_volunteer, name='approve_volunteer'),

    # 4. Transactions (Features: Fund Transfer & Ledger)
   path('transfer/', views.transfer_funds_page, name='transfer_funds_page'),
   path('fund/', views.fund_management, name='fund_management'),
    path('ledger/', views.blockchain_history, name='blockchain_history'),

    # 5. AI & Security (Features: Fraud Scan & Forecast)
    path('ai_fraud_scan', views.ai_fraud_scan, name='ai_fraud_scan'),
    
path('ai_forecast/', views.ai_forecast, name='ai_forecast'),
    # 6. Reports & Campaigns (Features: Impact & Fundraising)
    path('impact-reports/', views.impact_reports, name='impact_reports'),
    path('campaigns/', views.campaign_list, name='campaign_list'),
    path('payment/', views.payment_gateway, name='payment_gateway'),
    path('ledger/', views.blockchain_ledger, name='blockchain_ledger'),

    # 7. Smart Contracts (Feature 8)
    path('smart-contracts/', views.smart_contracts_view, name='smart_contract_list'),

    # 8. Communications (Features: Notifications & Messaging)
    path('notifications/', views.notifications_view, name='notifications'),
    path('messages/', views.donor_messages, name='messages'),

    # 9. Payment & System (Features: Payment Demo, Health, Settings)
    path('payment-demo/', views.dashboard_view, name='payment_demo'),
    path('system-status/', views.system_status, name='system_status'),
    path('settings/', views.admin_settings, name='admin_settings'),

    # API endpoints (For AJAX)
    path('get_live_stats/', views.get_live_stats, name='get_live_stats'),
]