import hashlib
from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# 1. Category Management (Feature 5 & 13)
class Category(models.Model):
    name = models.CharField(max_length=100)
    icon = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return self.name
    
# 2. NGO Profile & Core Management (Features 1, 2, 3, 10)
class NGO(models.Model):
    admin = models.ForeignKey(User, on_delete=models.CASCADE,related_name='ngo_admin_profiles', null=True, blank=True)
    name = models.CharField(max_length=255)
    location = models.CharField(max_length=100, default="Gujarat")
    description = models.TextField(blank=True, null=True)
    balance = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    is_active = models.BooleanField(default=True)
    
    # Impact & AI Prediction (Features 10, 11, 12)
    impact_score = models.FloatField(default=0.0) 
    prediction_status = models.CharField(max_length=50, default="Stable")
    
    # Blockchain Integrity (Feature 9)
    record_hash = models.CharField(max_length=64, editable=False, blank=True)

    def save(self, *args, **kwargs):
        # Digital fingerprint of the NGO's financial state
        hash_string = f"{self.name}{self.balance}{self.impact_score}"
        self.record_hash = hashlib.sha256(hash_string.encode()).hexdigest()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

# 3. Campaign & AI Forecasting (Features 11, 13)
class Campaign(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name='campaigns')
    title = models.CharField(max_length=200)
    goal_amount = models.DecimalField(max_digits=12, decimal_places=2)
    raised_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    category = models.CharField(max_length=100) 
    
    success_probability = models.FloatField(default=0.0) 
    forecasted_completion_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return self.title

# 4. Blockchain Transactions (Features 4, 6, 17)
class Transaction(models.Model):
    sender = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name='sent_transactions', null=True, blank=True)
    receiver = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name='received_transactions', null=True, blank=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)
    purpose = models.CharField(max_length=255, default="General Support", null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    is_flagged_as_fraud = models.BooleanField(default=False)
    fraud_risk_score = models.FloatField(default=0.0)
    
    # Blockchain Ledger
    block_hash = models.CharField(max_length=64, unique=True, editable=False, null=True, blank=True)
    previous_block_hash = models.CharField(max_length=64, editable=False, null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.block_hash:
            prev_tx = Transaction.objects.order_by('-id').first()
            self.previous_block_hash = prev_tx.block_hash if prev_tx else "0"
            content = f"{self.sender_id}{self.receiver_id}{self.amount}{self.previous_block_hash}"
            self.block_hash = hashlib.sha256(content.encode()).hexdigest()
        super().save(*args, **kwargs)

# 5. Emergency & Notifications (Features 5, 7, 9, 15)
class EmergencyRequest(models.Model):
    requesting_ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    requirement_details = models.TextField()
    estimated_cost = models.DecimalField(max_digits=10, decimal_places=2)
    is_emergency = models.BooleanField(default=True)
    status = models.CharField(max_length=20, choices=[('Pending', 'Pending'), ('Fullfilled', 'Fullfilled')], default='Pending')

class LiveNotification(models.Model):
    target_ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    message = models.CharField(max_length=255)
    category = models.CharField(max_length=50) 
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

class NGOMessage(models.Model):
    sender = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name='messages_sent')
    receiver = models.ForeignKey(NGO, on_delete=models.CASCADE, related_name='messages_received')
    content = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)

class ImpactReport(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    report_period = models.CharField(max_length=50) 
    total_beneficiaries = models.IntegerField(default=0)
    ai_summary = models.TextField()
    generated_at = models.DateTimeField(auto_now_add=True)

class Volunteer(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    skills = models.CharField(max_length=200)
    status = models.CharField(max_length=20, default='Pending') # Pending, Approved, Rejected
    applied_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name