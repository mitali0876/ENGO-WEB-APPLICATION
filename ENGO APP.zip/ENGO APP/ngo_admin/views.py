import random
from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db import transaction as db_transaction
from django.http import JsonResponse
from django.db.models import Avg, Sum
from volunteer.models import VolunteerProfile,Notification,NGORequirement, Donation
from django.db.models import F

from .models import (
    NGO, Campaign, Transaction, Category,Volunteer,
    LiveNotification, NGOMessage, ImpactReport, Transaction
)

# --- 1. MAIN DASHBOARD (HUB) ---
def dashboard_view(request):
    
    context = {
        'total_ngos': NGO.objects.count(),
        'pending_volunteers_count': Volunteer.objects.filter(status='Pending').count(),
        'total_impact': 88.5, # Static or dynamic impact score
    }
    return render(request, 'ngo_admin/dashboard.html', context)

# --- 2. NGO MANAGEMENT (Feature 1, 12) ---
def ngo_list(request):
    ngos = NGO.objects.all()
    return render(request, 'ngo_admin/ngo_list.html', {'ngos': ngos})

def create_ngo_page(request):
    if request.method == "POST":
        name = request.POST.get('name')
        location = request.POST.get('location')
        balance = request.POST.get('balance', 0)
        
        new_ngo = NGO.objects.create(
            admin=request.user,
            name=name,
            location=location,
            balance=balance
        )
        
        # Feature 9: Notification
        LiveNotification.objects.create(
            target_ngo=new_ngo,
            message=f"NGO {name} successfully deployed to blockchain.",
            category="System"
        )
        messages.success(request, f"NGO {name} created successfully!")
        return redirect('ngo_admin:ngo_list')
    
    return render(request, 'ngo_admin/create_ngo.html')

# --- 3. VOLUNTEER SYSTEM (Feature 2, 19) --
def volunteer_list(request):
    
    volunteers_data =VolunteerProfile.objects.all()
    print(f"DEBUG: Database count is {volunteers_data.count()}")
    
    return render(request, 'ngo_admin/volunteers.html', {'volunteers': volunteers_data})

def approve_volunteer(request, profile_id):
    profile = get_object_or_404(VolunteerProfile, id=profile_id)
    profile.status = 'Approved'
    profile.save()
    display_name = getattr(profile, 'name', f"Volunteer #{profile.id}")

    try:
        from volunteer.models import NGO, Notification
        target_ngo = NGO.objects.first()
        if target_ngo:
            Notification.objects.create(
                user=target_ngo.user,
                message=f"New volunteer '{display_name}' is ready for your work! 🎉"
            )
    except Exception as e:
        print(f"Notification Error: {e}")

    messages.success(request, f"Volunteer {display_name} approved successfully!")
    return redirect('ngo_admin:volunteer_list')

# --- 4. BLOCKCHAIN TRANSACTIONS (Feature 3, 4, 6) ---
def blockchain_history(request):
    transactions = Transaction.objects.all().order_by('-timestamp')
    return render(request, 'ngo_admin/blockchain_ledger.html', {'transactions': transactions})

def fund_management(request):
    
    ngos = NGO.objects.all()
    if request.method == "POST" and 'amount' in request.POST:
        sender_id = request.POST.get('sender_id')
        receiver_id = request.POST.get('receiver_id')
        amount = Decimal(request.POST.get('amount', 0))

        try:
            with db_transaction.atomic():
                sender = NGO.objects.select_for_update().get(id=sender_id)
                receiver = NGO.objects.select_for_update().get(id=receiver_id)

                if sender.balance >= amount:
                    sender.balance -= amount
                    receiver.balance += amount
                    sender.save()
                    receiver.save()
                    Transaction.objects.create(
                        sender=sender,
                        receiver=receiver,
                        amount=amount,
                        purpose="Inter-NGO Support"
                    )
                    messages.success(request, f"₹{amount} Transferred and Block Mined! 🚀")
                else:
                    messages.error(request, "Insufficient balance in sender NGO.")
        except Exception as e:
            messages.error(request, f"Error: {str(e)}")
        
        return redirect('ngo_admin:fund_management')
    requirements = NGORequirement.objects.all().order_by('-is_urgent', '-created_at')
    recent_donations = Donation.objects.all().order_by('-created_at')[:10]
    total_funds = Donation.objects.aggregate(Sum('amount'))['amount__sum'] or 0
    total_donors = Donation.objects.values('donor').distinct().count()

    context = {
        'ngos': ngos,
        'requirements': requirements,
        'recent_donations': recent_donations,
        'total_funds': total_funds,
        'total_donors': total_donors,
    }
    return render(request, 'ngo_admin/fund.html', context)

def fund_management(request):
    requirements = NGORequirement.objects.all().order_by('-is_urgent', '-created_at')
    recent_donations = Donation.objects.all().order_by('-created_at')[:10]
    
    # કુલ ફંડ અને ડોનર્સની ગણતરી
    total_funds = Donation.objects.aggregate(Sum('amount'))['amount__sum'] or 0
    total_donors = Donation.objects.values('donor').distinct().count()

    context = {
        'requirements': requirements,
        'recent_donations': recent_donations,
        'total_funds': total_funds,
        'total_donors': total_donors,
    }
    return render(request, 'ngo_admin/fund.html', context)


def transfer_funds_page(request):
    ngos = NGO.objects.all()
    
    if request.method == "POST":
        sender_id = request.POST.get('sender_id')
        receiver_id = request.POST.get('receiver_id')
        amount_val = request.POST.get('amount')

        if not sender_id or not receiver_id or not amount_val:
            messages.error(request, "બધી વિગતો ભરવી ફરજિયાત છે.")
            return redirect('ngo_admin:transfer_funds_page')

        if sender_id == receiver_id:
            messages.error(request, "સેન્ડર અને રિસીવર NGO અલગ હોવા જોઈએ.")
            return redirect('ngo_admin:transfer_funds_page')

        try:
            amount = Decimal(amount_val)
            

            with db_transaction.atomic():
                sender = NGO.objects.select_for_update().get(id=sender_id)
                receiver = NGO.objects.select_for_update().get(id=receiver_id)

                if sender.balance >= amount:
                    sender.balance -= amount
                    receiver.balance += amount
                    sender.save()
                    receiver.save()
                    Transaction.objects.create(
                        sender=sender,
                        receiver=receiver,
                        amount=amount,
                        purpose="Inter-NGO Support"
                    )
                    
                    messages.success(request, f"₹{amount} sucessfully transaction compelete and blockchiann hash generated...... 🔗")
                else:
                    messages.error(request, f"supply {sender.name} npot required money...")
        
        except Exception as e:
            messages.error(request, f"transaction faild..: {str(e)}")

        return redirect('ngo_admin:transfer_funds_page')

    return render(request, 'ngo_admin/fund_transfer.html', {'ngos': ngos})

# --- 5. AI & SECURITY (Feature 5, 6, 11, 13, 14) ---
def ai_fraud_scan(request):
    transactions = Transaction.objects.all().order_by('-timestamp')
    scanned_data = []

    for tx in transactions:
        risk_score = 0
        reasons = []

        if tx.amount > Decimal('50000'):
            risk_score += 40
            reasons.append("High amount transaction detected")
        if tx.amount % 1000 == 0:
            risk_score += 10
            reasons.append("Perfect round figure (Potential manually forced)")
        if risk_score >= 50:
            status = "Danger"
            color = "red"
        elif risk_score >= 30:
            status = "Warning"
            color = "amber"
        else:
            status = "Safe"
            color = "emerald"

        scanned_data.append({
            'tx': tx,
            'risk_score': risk_score,
            'status': status,
            'color': color,
            'reasons': reasons
        })

    return render(request, 'ngo_admin/ai_fraud_scan.html', {'scanned_data': scanned_data})

def ai_forecast(request):
   
    total_past_funds = Donation.objects.aggregate(Sum('amount'))['amount__sum'] or 0

    growth_rate = 1.15 
    predicted_fund = float(total_past_funds) * growth_rate
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
    actual_data = [10000, 15000, 12000, 18000, 25000, 22000]
    forecast_data = [12000, 17000, 14000, 20000, 28000, 30000] # AI Predicted

    context = {
        'total_past_funds': total_past_funds,
        'predicted_fund': round(predicted_fund, 2),
        'months': months,
        'actual_data': actual_data,
        'forecast_data': forecast_data,
        'confidence_score': 92, # AI Confidence %
    }
    return render(request, 'ngo_admin/ai_forecast.html', context)

# --- 6. IMPACT & CAMPAIGNS (Feature 7, 11) ---
def impact_reports(request):
    projects = NGORequirement.objects.filter(
        amount_received__gte=F('amount_needed')
    ).order_by('-id')
    total_lives = Donation.objects.count() * 5
    total_volunteers = 20

    context = {
        'projects': projects,
        'total_lives': total_lives,
        'total_volunteers': total_volunteers,
    }
    return render(request, 'ngo_admin/impact_reports.html', context)

def campaign_list(request):
    campaigns = NGORequirement.objects.all().order_by('-id')
    print(f"Total Campaigns Found: {campaigns.count()}") 
    
    return render(request, 'ngo_admin/campaigns.html', {'campaigns': campaigns})


def payment_gateway(request):
    amount = request.GET.get('amount', '0.00')
    return render(request, 'ngo_admin/payment_gateway.html', {'amount': amount})


def blockchain_ledger(request):
    transactions = Transaction.objects.all().order_by('-timestamp')
    return render(request, 'ngo_admin/blockchain_ledger.html', {'transactions': transactions})

# --- 7. NOTIFICATIONS & MESSAGING (Feature 9, 14) ---
def notifications_view(request):
    notifs = LiveNotification.objects.all().order_by('-created_at')
    return render(request, 'ngo_admin/notifications.html', {'notifications': notifs})

def donor_messages(request):
    
    return render(request, 'ngo_admin/messages.html')

# --- 8. SYSTEM & SMART CONTRACTS (Feature 8, 13, 15) ---
def smart_contracts_view(request):
    return render(request, 'ngo_admin/smart_contracts.html')

def system_status(request):
    # Simulating system health check
    status = {
        'blockchain_node': 'Active',
        'db_latency': '12ms',
        'ai_engine': 'Operational',
        'server_time': '2026-04-15'
    }
    return render(request, 'ngo_admin/system_status.html', {'status': status})


def admin_settings(request):
    # Use 'admin' because your model doesn't have a 'user' field
    ngo_profile = NGO.objects.filter(admin=request.user).first()
    
    return render(request, 'ngo_admin/settings.html', {
        'ngo_profile': ngo_profile
    })
# --- AJAX: LIVE STATS (Feature 10) ---
def get_live_stats(request):
    avg_impact = NGO.objects.aggregate(Avg('impact_score'))['impact_score__avg'] or 0
    return JsonResponse({
        "live_impact": round(avg_impact + random.uniform(-0.5, 0.5), 2),
        "new_notifs": LiveNotification.objects.filter(is_read=False).count()
    })