def predict_campaign_success(goal, duration_days):
    if goal < 100000 and duration_days < 30:
        return "High Success Probability"
    return "Medium Success Probability"
#🔹 Donation Forecasting
def forecast_donations(raised, days_passed):
    daily_avg = raised / max(days_passed, 1)
    return daily_avg * 30
#🔹 Fraud Detection
def detect_fraud(donations):
    suspicious = []
    for d in donations:
        if d.amount > 100000:
            suspicious.append(d)
    return suspicious
#🔹 Impact Measurement
def impact_score(people_helped, funds_used):
    return round(people_helped / funds_used, 2)