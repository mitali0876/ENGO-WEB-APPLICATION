from django.apps import AppConfig

class NgoAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ngo_admin'
