import hashlib


#🔹 Immutable Log
def generate_hash(data):
    return hashlib.sha256(str(data).encode()).hexdigest()

def log_expense(expense):
    data = f"{expense.campaign.id}{expense.amount}{expense.timestamp}"
    return generate_hash(data)