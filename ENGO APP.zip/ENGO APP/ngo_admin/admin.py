from django.contrib import admin
from .models import (
    Category, NGO, Campaign, Transaction, 
    EmergencyRequest, LiveNotification, 
    NGOMessage, ImpactReport, Volunteer
)

# 1. NGO Management
@admin.register(NGO)
class NGOAdmin(admin.ModelAdmin):
    list_display = ('name', 'admin', 'location', 'balance', 'impact_score', 'prediction_status', 'is_active')
    list_filter = ('location', 'prediction_status', 'is_active')
    search_fields = ('name', 'admin__username', 'record_hash')
    readonly_fields = ('record_hash',)
    fieldsets = (
        ('Basic Information', {'fields': ('admin', 'name', 'location', 'description', 'is_active')}),
        ('Financial & AI Stats', {'fields': ('balance', 'impact_score', 'prediction_status')}),
        ('Blockchain Security', {'fields': ('record_hash',)}),
    )

# 2. Blockchain Ledger (Transactions)
@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ('id', 'sender', 'receiver', 'amount', 'timestamp', 'is_flagged_as_fraud')
    list_filter = ('is_flagged_as_fraud', 'timestamp')
    search_fields = ('block_hash', 'previous_block_hash', 'purpose')
    readonly_fields = ('block_hash', 'previous_block_hash', 'timestamp')

# 3. Campaign Management
@admin.register(Campaign)
class CampaignAdmin(admin.ModelAdmin):
    list_display = ('title', 'ngo', 'goal_amount', 'raised_amount', 'category', 'success_probability')
    list_filter = ('category', 'ngo')
    search_fields = ('title', 'ngo__name')

# 4. Volunteer Management
@admin.register(Volunteer)
class VolunteerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'status', 'applied_at')
    list_filter = ('status',)
    search_fields = ('name', 'email', 'skills')
    actions = ['approve_volunteers', 'reject_volunteers']

    @admin.action(description='Approve selected volunteers')
    def approve_volunteers(self, request, queryset):
        queryset.update(status='Approved')

    @admin.action(description='Reject selected volunteers')
    def reject_volunteers(self, request, queryset):
        queryset.update(status='Rejected')

# 5. Emergency & Notifications
@admin.register(EmergencyRequest)
class EmergencyRequestAdmin(admin.ModelAdmin):
    list_display = ('title', 'requesting_ngo', 'estimated_cost', 'status', 'is_emergency')
    list_filter = ('status', 'is_emergency')

@admin.register(LiveNotification)
class LiveNotificationAdmin(admin.ModelAdmin):
    list_display = ('target_ngo', 'message', 'category', 'is_read', 'created_at')

# 6. Messaging & Reports
@admin.register(NGOMessage)
class NGOMessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'receiver', 'sent_at')

@admin.register(ImpactReport)
class ImpactReportAdmin(admin.ModelAdmin):
    list_display = ('ngo', 'report_period', 'total_beneficiaries', 'generated_at')

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon')