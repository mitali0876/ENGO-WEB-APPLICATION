# utils/ml.py

import joblib
import os
import numpy as np
from datetime import datetime

MODEL_PATH = os.path.join("ml", "donor_model.pkl")

# ================================
# 📦 LOAD MODEL
# ================================
def load_model():
    if os.path.exists(MODEL_PATH):
        return joblib.load(MODEL_PATH)
    return None


# ================================
# 🔮 DONOR PREDICTION
# ================================
def predict_donor_value(user):
    """
    Predict how much a user is likely to donate in future
    """

    model = load_model()

    donations = user.donation_set.all()

    if not donations or not model:
        return 0

    count = donations.count()
    avg_amount = sum([d.amount for d in donations]) / count

    # Days since last donation
    last_donation = donations.order_by('-created_at').first()
    days_gap = (datetime.now() - last_donation.created_at.replace(tzinfo=None)).days

    features = np.array([[count, avg_amount, days_gap]])

    prediction = model.predict(features)[0]

    return round(max(prediction, 0), 2)


# ================================
# 📊 CAMPAIGN SUCCESS PREDICTION
# ================================
def predict_campaign_success(project):
    """
    Predict campaign success %
    """

    goal = project.goal_amount
    raised = project.amount_raised

    if goal == 0:
        return 0

    ratio = raised / goal

    if ratio > 0.7:
        return 90
    elif ratio > 0.4:
        return 75
    elif ratio > 0.2:
        return 60
    else:
        return 40


# ================================
# 💰 DONATION FORECAST
# ================================
def forecast_donations(ngo):
    """
    Predict future donation growth
    """

    donations = ngo.transaction_set.filter(type="DONATION")

    if not donations:
        return 0

    total = sum([d.amount for d in donations])
    count = donations.count()

    avg = total / count

    # Simple trend multiplier
    growth_factor = 1.15 if count > 5 else 1.05

    forecast = total + (avg * growth_factor)

    return round(forecast, 2)


# ================================
# 🚨 FRAUD DETECTION (AI RULES)
# ================================
def detect_fraud(transaction):
    """
    Detect suspicious transactions
    """

    if transaction.amount > 500000:
        return True

    if transaction.type == "TRANSFER_OUT" and transaction.amount > 200000:
        return True

    return False


# ================================
# 🌍 DONOR SCORING (SMART TARGETING)
# ================================
def donor_score(user):
    """
    Score donor based on behavior
    """

    donations = user.donation_set.all()

    if not donations:
        return 0

    total = sum([d.amount for d in donations])
    frequency = donations.count()

    score = (total * 0.6) + (frequency * 100)

    return round(score, 2)


# ================================
# 🎯 RECOMMEND BEST CAMPAIGNS
# ================================
def recommend_campaigns(user, projects):
    """
    Recommend best campaigns for a donor
    """

    user_score = donor_score(user)

    recommended = []

    for project in projects:
        if project.goal_amount < user_score * 10:
            recommended.append(project)

    return recommended


# ================================
# 📈 IMPACT CALCULATION
# ================================
def calculate_impact(ngo):
    """
    AI-based NGO impact score
    """

    transactions = ngo.transaction_set.all()

    total = sum([t.amount for t in transactions if t.type == "DONATION"])
    projects = ngo.project_set.count()

    impact = (total / 10000) + (projects * 2)

    return round(impact, 2)