import numpy as np
from sklearn.ensemble import IsolationForest
from textblob import TextBlob

def analyze_sentiment(text):
    if not text:
        return "No report provided."
    
    analysis = TextBlob(text)
    score = analysis.sentiment.polarity
    
    # Categorizing the result for the dashboard
    if score > 0.5:
        return f"🌟 Excellent Impact (Score: {score:.2f})"
    elif score > 0:
        return f"✅ Positive Impact (Score: {score:.2f})"
    elif score == 0:
        return "⚪ Neutral / Factual Report"
    else:
        return f"⚠️ Negative Feedback (Score: {score:.2f})"
def detect_fraud(amounts):
    """
    Analyzes a list of donation amounts and returns a list of predictions:
    1 = Normal, -1 = Anomalous/Fraud.
    """
    if len(amounts) < 5:
        # Not enough data to train a model, assume all are normal
        return [1] * len(amounts)

    # Reshape to 2D array [n_samples, n_features] required by sklearn
    data = np.array(amounts).reshape(-1, 1)

    # contamination: estimated percentage of transactions that are outliers
    # We set it to 0.1 (10%) as a conservative starting point
    model = IsolationForest(n_estimators=100, contamination=0.1, random_state=42)
    
    # Fit the model and get predictions (-1 for outliers)
    predictions = model.fit_predict(data)
    return predictions.tolist()

def predict_next(amounts):
    """
    A simple moving average projection for the next donation amount.
    """
    if len(amounts) < 3:
        return sum(amounts) / len(amounts) if amounts else 0
    
    # Use the average of the last 3 donations for a simple trend prediction
    return sum(amounts[-3:]) / 3

def calculate_ai_score(total_funds, fraud_count):
    """
    Calculates a score based on growth and security.
    Formula: (Total / 100) - (Fraud_Count * 50)
    """
    # Ensures the score doesn't go below 0
    score = (total_funds / 100) - (fraud_count * 50)
    return max(0, score)