


from rest_framework.decorators import api_view
from rest_framework.response import Response
from .services.recommender import recommend_campaigns
@api_view(['GET'])
def ai_campaigns(request):
    campaigns = recommend_campaigns(request.user)
    return Response([c.title for c in campaigns])