from django.db import models

class NGO(models.Model):
    name = models.CharField(max_length=255)
    total_funds = models.FloatField(default=0)
    ai_score = models.FloatField(default=0)

    def __str__(self):
        return self.name


class Donation(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    amount = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    is_fraud = models.BooleanField(default=False)


class ImpactReport(models.Model):
    ngo = models.ForeignKey(NGO, on_delete=models.CASCADE)
    content = models.TextField()
    sentiment_score = models.FloatField(null=True)
