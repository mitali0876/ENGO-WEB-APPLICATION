from channels.generic.websocket import AsyncWebsocketConsumer
import json
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

class AIScoreConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        await self.channel_layer.group_add("ai_scores", self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard("ai_scores", self.channel_name)

    async def ai_score_update(self, event):
        await self.send(text_data=json.dumps(event["data"]))


def broadcast_ai_score(score):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        "ai_scores",
        {
            "type": "ai_score_update",
            "data": {"ai_score": score}
        }
    )
