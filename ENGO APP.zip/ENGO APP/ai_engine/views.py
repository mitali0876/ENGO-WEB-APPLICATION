import json
import requests
from django.shortcuts import render
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from textblob import TextBlob  
import ollama
# Import your local ML logic and models
from .models import Donation, NGO
from .ml_engine import predict_next, detect_fraud, calculate_ai_score


def ai_engine(request):
    return render(request, 'ai_engine/dashboard.html')

@api_view(["POST"])
def add_donation(request):
    # 1. Get NGO (Default to ID 1 for testing if not provided)
    ngo_id = request.data.get("ngo_id", 1)
    ngo = NGO.objects.get(id=ngo_id)

    # 2. Get amount
    amount = float(request.data.get("amount", 0))

    # 3. Create donation
    Donation.objects.create(
        ngo=ngo,
        amount=amount
    )

    # 4. Fetch donations
    donations = Donation.objects.filter(ngo=ngo)
    amounts = [float(d.amount) for d in donations]
    
    fraud_count = 0
    
    # 5. Fraud detection
    if len(amounts) >= 3: # ML models usually need at least 3 points
        fraud_predictions = detect_fraud(amounts)
        avg_amount = sum(amounts) / len(amounts)

        for donation_obj, pred in zip(donations, fraud_predictions):
            # Check ML prediction OR manual 5x threshold
            if pred == -1 or donation_obj.amount > avg_amount * 5:
                if not donation_obj.is_fraud: # Only update if changed
                    donation_obj.is_fraud = True
                    donation_obj.save()
                fraud_count += 1

    # 6. Calculate results
    total = sum(amounts)
    ai_score = calculate_ai_score(total, fraud_count)

    ngo.ai_score = ai_score
    ngo.total_funds = total
    ngo.save()

    # broadcast_ai_score(ai_score) # Commented out until Websockets are ready

    return Response({
        "ai_score": round(ai_score, 2),
        "fraud_count": fraud_count
    })

@api_view(["GET"])
def predict_donation(request, ngo_id):
    donations = Donation.objects.filter(ngo_id=ngo_id)
    amounts = [float(d.amount) for d in donations]
    if len(amounts) < 3:
        return Response({"prediction": "Insufficient data (need 3+ donations)"})
    
    prediction = predict_next(amounts)
    return Response({"prediction": round(prediction, 2)})

@csrf_exempt
def ask_gpt(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            user_message = data.get("message", "")

            
            response = ollama.chat(model='llama3', messages=[
                {
                    'role': 'user',
                    'content': user_message,
                },
            ])

            return JsonResponse({'reply': response['message']['content']})
        
        except Exception as e:
            return JsonResponse({'reply': f"Llama Error: {str(e)}"}, status=500)

@api_view(["POST"])
def nlp_sentiment(request):
    text = request.data.get("text", "")
    if not text:
        return Response({"result": "⚠️ No text provided", "score": 0})

    analysis = TextBlob(text)
    score = round(analysis.sentiment.polarity, 2)

    if score > 0.2:
        status = "🌟 Positive Impact"
    elif score < -0.2:
        status = "⚠️ Risk Detected"
    else:
        status = "⚪ Neutral/Factual"

    return Response({
        "result": status,
        "score": score,
        "detail": f"AI analyzed this report with a polarity of {score}."
    })