from django.urls import re_path
from .consumers import AIScoreConsumer

websocket_urlpatterns = [
    re_path(r"ws/ai-score/$", AIScoreConsumer.as_asgi()),
]
