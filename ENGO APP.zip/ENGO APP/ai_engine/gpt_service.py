from openai import OpenAI
import os

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def ask_gpt(question):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role":"system","content":"You are an NGO AI advisor."},
            {"role":"user","content":question}
        ]
    )
    return response.choices[0].message.content
