from django.urls import path
from . import views

app_name = "ai_engine"

urlpatterns = [
    
    path('', views.ai_engine, name='ai_engine'),
    # 2. Donation & Prediction API
    path('api/add-donation/', views.add_donation, name='add_donation'),
    path('api/predict/<int:ngo_id>/', views.predict_donation, name='predict_donation'),
    
    # 3. AI Intelligence API
    path('api/ask-gpt/', views.ask_gpt, name='ask_gpt'),
    path('api/nlp-sentiment/', views.nlp_sentiment, name='nlp_sentiment'),
]
