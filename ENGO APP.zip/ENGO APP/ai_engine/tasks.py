from celery import shared_task
from .models import Donation
from .ml_engine import predict_next

@shared_task
def retrain_models():
    donations = Donation.objects.all()
    amounts = [d.amount for d in donations]
    predict_next(amounts)
