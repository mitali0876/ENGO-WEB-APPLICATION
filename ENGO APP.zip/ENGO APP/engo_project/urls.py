from django.contrib import admin
from django.urls import path, include
from . import views as account_views
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic.base import RedirectView

from django.urls import path
urlpatterns = [
    path('admin/', admin.site.urls),

    # HOME PAGE
    path('', account_views.home, name='home'),
      path('accounts/', include('django.contrib.auth.urls')),
    # AUTH
    path('', include('accounts.urls')),
    path('',include('core.urls')),
    path('donor/', include('donor.urls')),
    path('volunteer/', include('volunteer.urls')),
    
    path('ngo/', include('ngo_admin.urls')),
    path('csr/', include('csr.urls')),
    path('system/', include('system_admin.urls')),
    path('ai-engine/', include('ai_engine.urls')),
    path('favicon.ico', RedirectView.as_view(url=settings.STATIC_URL + 'favicon.ico')),
    
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)