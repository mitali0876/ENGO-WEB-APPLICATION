from django.contrib import admin
from .models import Profile
from .models import UserDonation
@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'role', 'verified')
    list_editable = ('verified',)

    


admin.site.register(UserDonation)
