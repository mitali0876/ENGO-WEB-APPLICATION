from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from .models import Profile
from .models import CorporateCSRProfile

@receiver(post_save, sender=User)
def create_corporate_profile(sender, instance, created, **kwargs):
    if created:
        profile = Profile.objects.filter(user=instance).first()
        if profile and profile.role == 'corporate':
            CorporateCSRProfile.objects.create(
                user=instance,
                company_name=instance.username,
                csr_budget=0
            )