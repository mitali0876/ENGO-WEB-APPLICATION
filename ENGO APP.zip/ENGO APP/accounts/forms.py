from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile



class SignupForm(forms.ModelForm):
    password1 = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput)
    role = forms.ChoiceField(choices=[
        ('donor', 'Donor'),
        ('volunteer', 'Volunteer'),
        ('ngo', 'NGO'),
        ('corporate', 'Corporate'),
    ])

    class Meta:
        model = User
        fields = ['username', 'email']

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('password1') != cleaned_data.get('password2'):
            raise forms.ValidationError("Passwords do not match")
        return cleaned_data




class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username',)