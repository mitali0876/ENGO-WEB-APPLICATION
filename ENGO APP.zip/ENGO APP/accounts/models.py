from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    ROLE_CHOICES = (
        ('user', 'User'),
        ('donor', 'Donor'),
        ('volunteer', 'Volunteer'),
        ('ngo', 'NGO'),
        ('corporate', 'Corporate'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES,
        default='user',   # ✅ IMPORTANT
    )
    verified = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username




class UserDonation(models.Model):
    DONATION_TYPE_CHOICES = (
        ('money', 'Money'),
        ('food', 'Food'),
        ('clothes', 'Clothes'),
        ('medicine', 'Medicine'),
        ('other', 'Other'),
    )

    # Optional: link donation to logged-in user
    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    name = models.CharField(max_length=100)
    email = models.EmailField()

    donation_type = models.CharField(
        max_length=20,
        choices=DONATION_TYPE_CHOICES
    )

    amount = models.PositiveIntegerField(
        null=True,
        blank=True,
        help_text="Only for money donation"
    )

    description = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.name} - {self.donation_type}"