from django.urls import path
from . import views
app_name = "accounts"
urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login_view, name='login'),
    
    path('logout/', views.logout_view, name='logout'),
   
    path('donate/', views.user_donate, name='user_donate'),
    path('dashboard/user/', views.user_dashboard, name='user_dashboard'),
   
    path('dashboard/donor/', views.donor, name='donor'),
    path('dashboard/volunteer/', views.volunteer_dashboard, name='volunteer_dashboard'),
    path('dashboard/ngo/', views.ngo_dashboard, name='ngo_dashboard'),
    path('dashboard/corporate/', views.corporate_dashboard, name='corporate_dashboard'),
    path('',views.system_admin,name="system_admin"),
    path('ai-engine/', views.ai_engine, name='ai_engine'),
]
