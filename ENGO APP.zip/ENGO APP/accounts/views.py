from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import CustomUserCreationForm
from .models import Profile

from .models import UserDonation
from csr.models import CorporateCSRProfile
# ---------------- HOME ----------------
def home(request):
    return render(request, 'accounts/home.html')

# ---------------- SIGNUP ----------------
def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        role = request.POST.get('role', 'user')

        if form.is_valid():
            user = form.save()

            # ✅ Use get_or_create to avoid UNIQUE constraint error
            profile, created = Profile.objects.get_or_create(user=user)
            profile.role = role  # Update role if needed
            profile.save()

            login(request, user)

            if role == 'donor':
                return redirect('donor:donor')
            elif role == 'volunteer':
                return redirect('accounts:volunteer_dashboard')
            elif role == 'ngo':
                return redirect('ngo_admin:dashboard')
            elif role == 'corporate':
                
                    return redirect('accounts:corporate_dashboard')
                
            else:
                return redirect('accounts:user_dashboard')

        else:
            return render(request, 'accounts/signup.html', {'form': form})

    else:
        form = CustomUserCreationForm()
    return render(request, 'accounts/signup.html', {'form': form})


# ---------------- LOGIN ----------------
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)
            profile, _ = Profile.objects.get_or_create(user=user)

            # Redirect based on role
            if profile.role == 'donor':
                return redirect('donor:donor')
            elif profile.role == 'volunteer':
                return redirect('accounts:volunteer_dashboard')
            elif profile.role == 'ngo':
                return redirect('ngo_admin:dashboard')
            elif profile.role == 'corporate':
                return redirect('accounts:corporate_dashboard')
            else:
                return redirect('accounts:user_dashboard')
        else:
            messages.error(request, 'Invalid username or password')

    return render(request, 'accounts/login.html')


# ---------------- LOGOUT ----------------
@login_required
def logout_view(request):
    logout(request)
    return redirect('accounts/login.html')


# ---------------- DASHBOARDS ----------------
@login_required
def user_dashboard(request):
    return render(request, 'accounts/dashboards/user.html')

@login_required
def donor(request):
    return render(request, 'donor/donor.html')

@login_required
def volunteer_dashboard(request):
    return render(request, 'volunteers/volunteer_dashboard.html')

@login_required
def ngo_dashboard(request):
    return render(request, 'ngo_admin/dashboard.html')

@login_required
def corporate_dashboard(request):
    return render(request, 'csr/corporate.html')


def user_donate(request):
    if request.method == "POST":
        UserDonation.objects.create(
            name=request.POST.get("name"),
            email=request.POST.get("email"),
            donation_type=request.POST.get("donation_type"),
            amount=request.POST.get("amount"),
            description=request.POST.get("description"),
        )

        messages.success(request, "🎉 Donation Successful! Thank you ❤️")
    return render(request, "accounts/dashboards/user_donate.html")


def system_admin(request):
    return render(request, 'system_admin/system_admin.html')


def ai_engine(request):
    return render(request, 'ai_engine/ai_engine.html')  
