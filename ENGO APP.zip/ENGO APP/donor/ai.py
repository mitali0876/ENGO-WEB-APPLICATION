from .models import Donation, Campaign
from django.db.models import Sum, Avg
from django.utils.timezone import now
from datetime import timedelta

def recommend_campaigns(donor):
    donated = Donation.objects.filter(donor=donor).values_list('campaign', flat=True)
    return Campaign.objects.exclude(id__in=donated)[:5]

def donor_behavior(donor):
    return {
        'total_donations': Donation.objects.filter(donor=donor).count(),
        'average_amount': Donation.objects.filter(donor=donor).aggregate(Avg('amount'))
    }

def predict_churn(donor):
    last = Donation.objects.filter(donor=donor).latest('created_at')
    return now() - last.created_at > timedelta(days=90)

def donor_ltv(donor):
    return Donation.objects.filter(donor=donor).aggregate(Sum('amount'))

def predict_next_donation(username):
    qs = Donation.objects.filter(donor__username=username)
    if not qs.exists():
        return 0
    avg = qs.aggregate(Avg('amount'))['amount__avg']
    return round(avg * 1.15, 2)
