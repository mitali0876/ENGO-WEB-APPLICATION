from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Donation
from .ai_fraud import detect_fraud
from .ai_prediction import predict_campaign_donation

@receiver(post_save, sender=Donation)
def update_prediction(sender, instance, created, **kwargs):
    if created:
        predict_campaign_donation(instance.campaign)


@receiver(post_save, sender=Donation)
def run_fraud_detection(sender, instance, created, **kwargs):
    if created:
        detect_fraud(instance)
