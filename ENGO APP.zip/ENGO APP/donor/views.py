from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db.models import Sum, Q
from django.db import transaction
from django.contrib import messages
from django.contrib.auth.models import User
from decimal import Decimal
import datetime
import random
import uuid
from .models import Campaign, TrustLedger, VolunteerSkill, Donation
# Main Dashboard
@login_required
def donor(request):
    
    total_count = Donation.objects.count()
    total_income = Campaign.objects.aggregate(res=Sum('raised_amount'))['res'] or 0
    
    context = {
        'total_count': total_count,
        'total_income': total_income,
    }
    return render(request, 'donor/donor.html', context)

# 16 Feature Views
def explore_campaigns(request):
    
    campaigns = Campaign.objects.all().order_by('-created_at')
   
    print(f"Total Campaigns found: {campaigns.count()}") 
    
    return render(request, 'donor/explore_campaigns.html', {'campaigns': campaigns})



import uuid # Transaction ID માટે

def process_donation(request, campaign_id):
    if request.method == "POST":
        try:
            campaign = get_object_or_404(Campaign, id=campaign_id)
            amount = request.POST.get('amount')
            
            if amount:
                amt_dec = Decimal(str(amount))
                
                with transaction.atomic():
                    
                    Donation.objects.create(
                        campaign=campaign,
                        amount=amt_dec,
                        donor=request.user if request.user.is_authenticated else None
                    )
                   
                    
                    TrustLedger.objects.create(
                        campaign=campaign,
                        donor_name=request.user.username if request.user.is_authenticated else "Anonymous",
                        amount=amt_dec,
                        transaction_id=f"TXN-{uuid.uuid4().hex[:10].upper()}" # Unique ID
                    )
                    
                    campaign.raised_amount = Decimal(str(campaign.raised_amount or 0)) + amt_dec
                    campaign.save()
                
                return JsonResponse({"status": "success", "message": "Donation recorded in Ledger!"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

@login_required
def delete_campaign(request, campaign_id):
    if request.method == "POST":
        campaign = get_object_or_404(Campaign, id=campaign_id)
        campaign.delete()
        return JsonResponse({"status": "success", "message": "Campaign deleted!"})
    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def trust_ledger(request):
    
    transactions = TrustLedger.objects.all().order_by('-timestamp')
    return render(request, 'donor/trust_ledger.html', {'transactions': transactions})
def impact_wallet(request):
    # 1. Donor side na Campaigns no total sum (goal_amount field)
    total_donor = Campaign.objects.aggregate(res=Sum('goal_amount'))['res'] or 0
    
    # 2. Total projects count
    active_projects = Campaign.objects.count()
    
    # 3. Dummy Fail-safe: Jo database khali hoy to demo mate data set karo
    if total_donor == 0:
        total_funded = 485000  # Manual value for demo
        active_projects = 14
        lives_impacted = 12500
    else:
        total_funded = float(total_donor)
        lives_impacted = int(total_funded / 100)

    context = {
        'total_funded': total_funded,
        'active_projects': active_projects,
        'lives_impacted': lives_impacted,
    }
    return render(request, 'donor/impact_wallet.html', context)

def donor_roles(request): 
    return render(request, 'donor/donor_roles.html')

def ai_predictor(request):
    # Dummy ML Insights - Mitali, tame ahiya tamara real model nu logic muki shako
    predictions = [
        {'category': 'Education', 'success_rate': 92, 'impact_score': 'High'},
        {'category': 'Environment', 'success_rate': 85, 'impact_score': 'Medium'},
        {'category': 'Healthcare', 'success_rate': 78, 'impact_score': 'High'},
    ]
    
    context = {
        'predictions': predictions,
        'ai_confidence': random.randint(94, 98), # AI Confidence Score
    }
    return render(request, 'donor/ai_predictor.html', context)


from django.shortcuts import render
from .models import TrustLedger
import datetime

def live_updates(request):
    # Database mathi latest 10 transactions lavo
    updates = TrustLedger.objects.all().order_by('-timestamp')[:10]
    
    context = {
        'updates': updates,
        'current_time': datetime.datetime.now(),
    }
    return render(request, 'donor/live_updates.html', context)




def skill_donation(request, campaign_id=None):
    campaign = None
    if campaign_id:
        campaign = Campaign.objects.filter(id=campaign_id).first()

    if request.method == "POST":
        v_skill = request.POST.get('skill_type')
        v_hours = request.POST.get('hours')
        
        # User handle karo
        if request.user.is_authenticated:
            current_user = request.user
        else:
            current_user = User.objects.first() 

        # 1. Pehla object create karo (ManyToMany field vagar)
        new_skill = VolunteerSkill.objects.create(
            donor=current_user,
            skill_name=v_skill,
            hours_donated=v_hours
        )

        # 2. 
        if campaign:
            # Jo 'voted_projects' ManyToMany field hoy to:
            new_skill.voted_projects.add(campaign)
        
        messages.success(request, "✅ Skill Donation Saved successfully!")

    return render(request, 'donor/skill_donations.html', {'campaign': campaign})

def tax_benefits(request):
    
    user_total = TrustLedger.objects.filter(donor_name=request.user.username).aggregate(res=Sum('amount'))['res'] or 50000
    
    # 80G m
    tax_savings = float(user_total) * 0.50
    
    context = {
        'total_donation': user_total,
        'tax_savings': tax_savings,
        'pan_status': "Verified",
    }
    return render(request, 'donor/tax_benefits.html', context)
def gift_cause(request):
    campaigns = Campaign.objects.all() # Badha causes select karva mate
    
    if request.method == "POST":
        recipient_name = request.POST.get('recipient_name')
        occasion = request.POST.get('occasion')
        # ... logic to send email or save gift donation ...
        
        messages.success(request, f"🎁 Gift Card sent to {recipient_name} for their {occasion}!")
        

    return render(request, 'donor/gift_cause.html', {'campaigns': campaigns})


def impact_nfts(request):
    # Dummy NFT Data - Mitali, 
    nfts = [
        {'id': '#001', 'name': 'Green Warrior', 'category': 'Environment', 'status': 'Unlocked', 'rarity': 'Rare'},
        {'id': '#002', 'name': 'Knowledge Pillar', 'category': 'Education', 'status': 'Locked', 'rarity': 'Legendary'},
        {'id': '#003', 'name': 'Life Savior', 'category': 'Healthcare', 'status': 'Unlocked', 'rarity': 'Common'},
    ]
    
    context = {
        'nfts': nfts,
        'wallet_balance': "1.24 ETH", # Blockchain Feel mate
    }
    return render(request, 'donor/impact_nfts.html', context)


def dao_voting(request):
    
    proposals = Campaign.objects.all().order_by('-created_at')
    
   
    context = {
        'proposals': proposals,
        'wallet_balance': "1.24 ETH",
    }
    
    return render(request, 'donor/dao_voting.html', context)

def eco_tracker(request):
    # Dummy Tracking Data 
    impact_stats = {
        'carbon_offset': 1240, # in kg
        'trees_planted': 540,
        'water_saved': 15000, # in liters
        'plastic_recycled': 850, # in kg
        'active_projects': 12
    }
    
    # Timeline data for impact tracking
    milestones = [
        {'date': 'April 2026', 'event': '500kg Plastic Recycled in Surat Beach Drive', 'icon': 'recycle'},
        {'date': 'March 2026', 'event': 'Solar Grid Active in 3 Rural Schools', 'icon': 'sun'},
        {'date': 'Feb 2026', 'event': '10,000 Liters Water Saved through Smart Irrigation', 'icon': 'droplet'},
    ]

    return render(request, 'donor/eco_tracker.html', {
        'stats': impact_stats,
        'milestones': milestones
    })


def ai_audit(request):
    # 1. 
    all_campaigns = Campaign.objects.all().order_by('-ai_trust_score')
    
    # 2. Audit Logs 
    audit_logs = [
        {'time': 'Just Now', 'event': 'Neural Network Scan: 100% Integrity', 'status': 'Verified'},
        {'time': '5 mins ago', 'event': 'Blockchain Ledger Hash Synced', 'status': 'Safe'},
        {'time': '12 mins ago', 'event': 'Smart Grid Surat - Transaction Audit', 'status': 'Success'},
        {'time': '1 hour ago', 'event': 'Anomalies Detected: 0', 'status': 'Clean'},
    ]
    
    context = {
        'campaigns': all_campaigns,
        'logs': audit_logs,
    }
    
    return render(request, 'donor/ai_audit.html', context)
def anonymous_giving(request):
    
    campaigns = Campaign.objects.filter(is_active=True)
    anonymous_id = f"ANON-{uuid.uuid4().hex[:8].upper()}"
    context = {
        'campaigns': campaigns,
        'anonymous_id': anonymous_id,
        'security_status': 'Encrypted'
    }
    return render(request, 'donor/anonymous_giving.html', context)

def milestone_tracker(request):
    # Live Data Access
    total_raised = Campaign.objects.aggregate(Sum('raised_amount'))['raised_amount__sum'] or Decimal('0')
    total_goal = Campaign.objects.aggregate(Sum('goal_amount'))['goal_amount__sum'] or Decimal('0')
    
    # Prediction Logic Fix: 4.5 ne Decimal()
    prediction_factor = Decimal('4.5') 
    predicted_fund = total_raised * prediction_factor
    
    # Trust Score Logic
    avg_trust = Campaign.objects.aggregate(Sum('ai_trust_score'))['ai_trust_score__sum'] or 0
    campaign_count = Campaign.objects.count()
    final_trust_avg = round(avg_trust / campaign_count, 1) if campaign_count > 0 else 0

    milestones = [
        {'title': 'Phase 1: Fund Collection', 'status': 'Completed', 'progress': 100},
        {'title': 'Phase 2: Execution', 'status': 'In Progress', 'progress': int((total_raised/total_goal)*100) if total_goal > 0 else 0},
        {'title': 'Phase 3: Impact Prediction', 'status': 'AI Analyzing', 'progress': 85},
    ]

    return render(request, 'donor/milestone_tracker.html', {
        'total_raised': total_raised,
        'predicted_fund': predicted_fund, # Rounding automatically Decimal ma thai jase
        'trust_avg': final_trust_avg,
        'milestones': milestones,
        'total_goal': total_goal
    })



def auto_pledge(request):
    # 1.
    campaigns = Campaign.objects.filter(is_active=True).order_by('-ai_trust_score')

    # 2. 
    total_impact = Campaign.objects.aggregate(Sum('raised_amount'))['raised_amount__sum'] or Decimal('0')
    
    # Active Rules
    high_trust_count = Campaign.objects.filter(ai_trust_score__gte=90).count()

    context = {
        'campaigns': campaigns,
        'stats': {
            'total_automated': total_impact,
            'active_pledges': high_trust_count,
            'next_run': 'Update Live'
        }
    }
    
    return render(request, 'donor/auto_pledge.html', context)


from .models import Donation  

def get_live_donations(request):
    count = Donation.objects.count()
    income = Campaign.objects.aggregate(res=Sum('raised_amount'))['res'] or 0
    return JsonResponse({
        'count': count,
        'total_income': float(income)
    })