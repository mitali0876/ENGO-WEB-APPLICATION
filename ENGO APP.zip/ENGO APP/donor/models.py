from django.db import models
from django.contrib.auth.models import User
import uuid

# 1. NGO Campaigns (Feature 1, 13, 15)
class Campaign(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='campaign_images/')
    goal_amount = models.DecimalField(max_digits=12, decimal_places=2)
    raised_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    ai_trust_score = models.IntegerField(default=85)  # Feature 13: AI Audit
    category = models.CharField(max_length=100) # e.g., Green, Education
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    def __str__(self):
        return self.title

# 2. Donor Profile (Feature 3, 4, 12, 16)
class DonorProfile(models.Model):
    ROLE_CHOICES = [
        ('Financier', 'Financier'),
        ('Mentor', 'Mentor'),
        ('Volunteer', 'Volunteer'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0) # Feature 3
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='Financier') # Feature 4
    eco_score = models.IntegerField(default=0) # Feature 12: CO2 Tracker
    is_anonymous = models.BooleanField(default=False) # Feature 14: Privacy
    
    def __str__(self):
        return self.user.username

# 3. Transactions & Ledger (Feature 2, 8, 10)
class Donation(models.Model):
    donor = models.ForeignKey(User, on_delete=models.CASCADE,null=True, blank=True)
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    tx_hash = models.CharField(max_length=100, default=uuid.uuid4) # Feature 2: Blockchain
    is_tax_receipt_generated = models.BooleanField(default=False) # Feature 8
    nft_token_id = models.CharField(max_length=100, blank=True, null=True) # Feature 10: NFT
    timestamp = models.DateTimeField(auto_now_add=True)

# 4. Volunteer Skills (Feature 7, 11)
class VolunteerSkill(models.Model):
    donor = models.ForeignKey(User, on_delete=models.CASCADE)
    skill_name = models.CharField(max_length=100) # e.g., Python Developer
    hours_donated = models.IntegerField(default=0)
    voted_projects = models.ManyToManyField(Campaign, blank=True) # Feature 11: DAO Voting

# 5. Milestone Tracker (Feature 15)
class Milestone(models.Model):
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE, related_name='milestones')
    title = models.CharField(max_length=200)
    is_completed = models.BooleanField(default=False)

class TrustLedger(models.Model):
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE)
    donor_name = models.CharField(max_length=255)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    transaction_id = models.CharField(max_length=100, unique=True)
    status = models.CharField(max_length=20, default='Success') # Success/Pending
    timestamp = models.DateTimeField(auto_now_add=True)
    blockchain_hash = models.CharField(max_length=256, null=True, blank=True) # Future mate

    def __str__(self):
        return f"{self.donor_name} - {self.amount}"