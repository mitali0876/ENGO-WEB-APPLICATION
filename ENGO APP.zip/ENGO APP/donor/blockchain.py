import hashlib

def generate_blockchain_hash(donation):
    raw = f"{donation.donor_id}{donation.amount}{donation.created_at}"
    return hashlib.sha256(raw.encode()).hexdigest()
