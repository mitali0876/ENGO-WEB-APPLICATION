from django.contrib import admin
# Wallet kadhi nakho ane tena badle DonorProfile add karo
from .models import Campaign, Donation, DonorProfile, VolunteerSkill, Milestone

admin.site.register(Campaign)
admin.site.register(Donation)
admin.site.register(DonorProfile) # Wallet na badle aa register karo
admin.site.register(VolunteerSkill)
admin.site.register(Milestone)