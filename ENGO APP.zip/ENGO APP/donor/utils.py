from .models import Donation
import hashlib

def verify_donation_chain():
    donations = Donation.objects.order_by('id')

    for i in range(1, len(donations)):
        prev = donations[i - 1]
        current = donations[i]

        expected_hash = hashlib.sha256(
            f"{current.donor_id}{current.campaign_id}{current.amount}{current.created_at}{prev.current_hash}".encode()
        ).hexdigest()

        if current.current_hash != expected_hash:
            return False

    return True
