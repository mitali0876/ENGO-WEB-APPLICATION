from django.urls import path
from . import views

app_name = 'donor'

urlpatterns = [
     path('', views.donor, name='donor'),
    path('explore/', views.explore_campaigns, name='explore_campaigns'),
   path('donate/<int:campaign_id>/', views.process_donation, name='process_donation'),
  path('delete-campaign/<int:campaign_id>/', views.delete_campaign, name='delete_campaign'),
    path('ledger/', views.trust_ledger, name='trust_ledger'),
    path('wallet/', views.impact_wallet, name='impact_wallet'),
    path('roles/', views.donor_roles, name='donor_roles'),
    path('ai-impact/', views.ai_predictor, name='ai_predictor'),
    path('live-feed/', views.live_updates, name='live_updates'),
    path('skills/', views.skill_donation, name='skill_donation'),
    path('tax/', views.tax_benefits, name='tax_benefits'),
    path('gift/', views.gift_cause, name='gift_cause'),
    path('nfts/', views.impact_nfts, name='impact_nfts'),
    path('dao/', views.dao_voting, name='dao_voting'),
    path('eco-score/', views.eco_tracker, name='eco_tracker'),
    path('audit/', views.ai_audit, name='ai_audit'),
    path('privacy/', views.anonymous_giving, name='anonymous_giving'),
    path('milestones/', views.milestone_tracker, name='milestone_tracker'),
    path('recurring/', views.auto_pledge, name='auto_pledge'),
    path('get-live-donations/', views.get_live_donations, name='get_live_donations'),
]